# Databricks notebook source
# MAGIC %md
# MAGIC ## Mounting ADLS Container in Databricks

# COMMAND ----------

mount_point = "/mnt/ys255066"

# Check if already mounted
mounted_paths = [mnt.mountPoint for mnt in dbutils.fs.mounts()]
if mount_point not in mounted_paths:
    dbutils.fs.mount(
        source="wasbs://ys255066@tdaastrgdls.blob.core.windows.net/",
        mount_point=mount_point,
        extra_configs={
            "fs.azure.account.key.tdaastrgdls.blob.core.windows.net": "Ping me on linkedin for credential. My linkedin profile: www.linkedin.com/in/yash-chandresh-shah"
        }
    )
    print(f"Mounted successfully at {mount_point}")
else:
    print(f"Already mounted at {mount_point}")
