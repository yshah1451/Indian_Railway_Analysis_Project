# Databricks notebook source
from pyspark.sql.functions import col, date_format, to_timestamp, udf
from pyspark.sql.types import IntegerType, TimestampType
import re

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading Delay_details parquet file from Staging layer in Databricks Using PySpark

# COMMAND ----------

df = spark.read.format("parquet").option("header", "true").option("inferSchema", "true").load("dbfs:/mnt/ys255066/Input/delay_details/delay_details.parquet")

df.printSchema() # Print the schema of the DataFrame
display(df) # Display the DataFrame in Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transforming delay details DataFrame in PySpark

# COMMAND ----------

# Define a UDF to convert Delay strings to minutes (Integer)
def convert_delay(delay_str):
    if delay_str is None:
        return 0
    delay_str = delay_str.lower().strip()
    hours = 0
    minutes = 0
    # Extract hours if available
    hour_match = re.search(r'(\d+)\s*hr[s]?', delay_str)
    if hour_match:
        hours = int(hour_match.group(1))
    # Extract minutes if available
    minute_match = re.search(r'(\d+)\s*min[s]?', delay_str)
    if minute_match:
        minutes = int(minute_match.group(1))
    return hours * 60 + minutes

# Register the UDF
convert_delay_udf = udf(convert_delay, IntegerType())

# Transform the DataFrame
df_transformed = df.withColumn("Train_id", col("Train_id").cast("int")) \
    .withColumn("Arrival_time", to_timestamp(col("Arrival_time"))) \
    .withColumn("Departure_time", to_timestamp(col("Departure_time"))) \
    .withColumn("Delay", convert_delay_udf(col("Delay"))) \
    .withColumn("Record_Load_Time", to_timestamp(col("Record_Load_Time"), "yyyy-MM-dd HH:mm:ss"))

# Display the new schema and a sample of the data
df_transformed.printSchema()
display(df_transformed)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Writing Delay details Transformed Data to Delta Table in PySpark

# COMMAND ----------

df_transformed.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save("dbfs:/mnt/ys255066/Delta/delay_details/")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating a delay_details Delta Table in Databricks Using SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.delay_details (
# MAGIC     Train_id INTEGER,
# MAGIC     Train_name STRING,
# MAGIC     Arrival_time TIMESTAMP,
# MAGIC     Departure_time TIMESTAMP,
# MAGIC     Delay INTEGER,
# MAGIC     Batch_Id STRING,
# MAGIC     Record_Load_Time TIMESTAMP
# MAGIC ) 
# MAGIC USING DELTA
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Delta/delay_details/';

# COMMAND ----------

# MAGIC %md
# MAGIC ## Querying the delay_details Delta Table in Databricks

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM ys255066.delay_details;