# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading satisfaction_details parquet file from Staging layer in Databricks Using PySpark

# COMMAND ----------

df = spark.read.format("parquet").option("header", "true").option("inferSchema", "true").load("dbfs:/mnt/ys255066/Input/satisfaction_details/satisfaction_details.parquet")

df.printSchema() # Print the schema of the DataFrame
display(df) # Display the DataFrame in Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🚀 Transforming Satisfaction details DataFrame in PySpark

# COMMAND ----------

# Apply transformations to change only required columns
df_transformed = df \
    .withColumn("Train_id", col("Train_id").cast("int")) \
    .withColumnRenamed("Status ", "Status")\
    .withColumn("Record_Load_Time", to_timestamp(col("Record_Load_Time"), "yyyy-MM-dd HH:mm:ss"))\
    .withColumn("Effective_Date", current_timestamp()) \
    .withColumn("End_Date", lit("9999-12-31").cast("timestamp")) \
    .withColumn("Is_Current", lit(1))

# Print schema and sample data to verify changes
df_transformed.printSchema()
display(df_transformed)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating temp view and using it to create silver layer delta table satisfaction_details.

# COMMAND ----------

df_transformed.createOrReplaceTempView("Satisfaction_details")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.satisfaction_details (
# MAGIC     Train_id INT,
# MAGIC     Train_name STRING,
# MAGIC     Seats_available STRING,
# MAGIC     Cleanliness STRING,
# MAGIC     Status STRING,
# MAGIC     Satisfaction STRING,
# MAGIC     Batch_Id STRING,
# MAGIC     Record_Load_Time TIMESTAMP,
# MAGIC     Effective_Date TIMESTAMP,
# MAGIC     End_Date TIMESTAMP,
# MAGIC     Is_Current INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Delta/satisfaction_details/';

# COMMAND ----------

# MAGIC %md
# MAGIC ## Applying SCD2 logic: Closing old record when matched with changes and inserting record that are not present in table.

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO ys255066.satisfaction_details AS target
# MAGIC USING Satisfaction_details AS source
# MAGIC ON target.Train_id = source.Train_id AND target.Is_Current = 1
# MAGIC WHEN MATCHED AND (
# MAGIC     target.Train_name <> source.Train_name
# MAGIC     OR target.Seats_available <> source.Seats_available
# MAGIC     OR target.Cleanliness <> source.Cleanliness
# MAGIC     OR target.Status <> source.Status
# MAGIC     OR target.Satisfaction <> source.Satisfaction
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     target.End_Date = source.Effective_Date,
# MAGIC     target.Is_Current = 0
# MAGIC WHEN NOT MATCHED
# MAGIC THEN INSERT (
# MAGIC     Train_id,
# MAGIC     Train_name,
# MAGIC     Seats_available,
# MAGIC     Cleanliness,
# MAGIC     Status,
# MAGIC     Satisfaction,
# MAGIC     Batch_Id,
# MAGIC     Record_Load_Time,
# MAGIC     Effective_Date,
# MAGIC     End_Date,
# MAGIC     Is_Current
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.Train_id,
# MAGIC     source.Train_name,
# MAGIC     source.Seats_available,
# MAGIC     source.Cleanliness,
# MAGIC     source.Status,
# MAGIC     source.Satisfaction,
# MAGIC     source.Batch_Id,
# MAGIC     source.Record_Load_Time,
# MAGIC     source.Effective_Date,
# MAGIC     '9999-12-31', -- Set End_Date to a far future date for new records
# MAGIC     1 -- Set Is_Current to 1 for new records
# MAGIC );

# COMMAND ----------

# MAGIC %md
# MAGIC ## Apply SCD2 Logic: Inserting latest record after closing old record.

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO ys255066.satisfaction_details AS target
# MAGIC USING Satisfaction_details AS source
# MAGIC ON target.Train_id = source.Train_id AND target.Is_Current = 1
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     Train_id,
# MAGIC     Train_name,
# MAGIC     Seats_available,
# MAGIC     Cleanliness,
# MAGIC     Status,
# MAGIC     Satisfaction,
# MAGIC     Batch_Id,
# MAGIC     Record_Load_Time,
# MAGIC     Effective_Date,
# MAGIC     End_Date,
# MAGIC     Is_Current
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.Train_id,
# MAGIC     source.Train_name,
# MAGIC     source.Seats_available,
# MAGIC     source.Cleanliness,
# MAGIC     source.Status,
# MAGIC     source.Satisfaction,
# MAGIC     source.Batch_Id,
# MAGIC     source.Record_Load_Time,
# MAGIC     source.Effective_Date,
# MAGIC     '9999-12-31', -- Set End_Date to a far future date for new records
# MAGIC     1 -- Set Is_Current to 1 for new records
# MAGIC );

# COMMAND ----------

# MAGIC %md
# MAGIC ## Querying the satisfaction_details Delta Table in Databricks

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.satisfaction_details order by Train_id