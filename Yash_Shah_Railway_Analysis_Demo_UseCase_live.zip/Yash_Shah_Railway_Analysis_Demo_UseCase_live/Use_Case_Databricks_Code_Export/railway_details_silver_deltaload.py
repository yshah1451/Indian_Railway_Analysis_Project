# Databricks notebook source
from pyspark.sql.functions import col, date_format, to_timestamp
from pyspark.sql.types import IntegerType, TimestampType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading Railway_details parquet file from Staging layer in Databricks Using PySpark

# COMMAND ----------

#The following PySpark code reads a Parquet file from ADLS (Azure Data Lake Storage) mounted on Databricks:
    
df = spark.read.format("parquet").option("header", "true").option("inferSchema", "true").load("dbfs:/mnt/ys255066/Input/railway_details/railway_details.parquet")

df.printSchema() # Print the schema of the DataFrame
display(df) # Display the DataFrame in Databricks

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Transforming Railway details DataFrame in PySpark
# MAGIC
# MAGIC

# COMMAND ----------

#The following **PySpark** code modifies column data types in a **DataFrame**:

df_transformed = df.withColumn("Train_id", col("Train_id").cast(IntegerType())) \
                   .withColumn("Record_Load_Time", to_timestamp(col("Record_Load_Time"), "yyyy-MM-dd HH:mm:ss"))

df_transformed.printSchema() # Print the schema of the DataFrame
display(df_transformed) # Display the DataFrame in Databricks


# COMMAND ----------

# MAGIC %md
# MAGIC ## Writing Railway details Transformed Data to Delta Table in PySpark

# COMMAND ----------

df_transformed.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save("dbfs:/mnt/ys255066/Delta/railway_details/")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating a railway_details Delta Table in Databricks Using SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS ys255066;
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.railway_details (
# MAGIC     Train_id INT,
# MAGIC     Train_name STRING,
# MAGIC     Train_color STRING,
# MAGIC     Distance STRING,
# MAGIC     Src_Station_name STRING,
# MAGIC     Dest_station_name STRING,
# MAGIC     Frequency STRING,
# MAGIC     Batch_Id STRING,
# MAGIC     Record_Load_Time TIMESTAMP
# MAGIC ) USING DELTA
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Delta/railway_details/';

# COMMAND ----------

# MAGIC %md
# MAGIC ## Querying the railway_details Delta Table in Databricks

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM ys255066.railway_details;