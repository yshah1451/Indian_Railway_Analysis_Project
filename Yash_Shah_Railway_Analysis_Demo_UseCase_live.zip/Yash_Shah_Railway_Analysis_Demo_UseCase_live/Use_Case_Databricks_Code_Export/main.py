# Databricks notebook source
# MAGIC %run /Workspace/ys255066/mount_adls_container

# COMMAND ----------

# MAGIC %run /Workspace/ys255066/railway_details_silver_deltaload

# COMMAND ----------

# MAGIC %run /Workspace/ys255066/delay_details_silver_deltaload

# COMMAND ----------

# MAGIC %run /Workspace/ys255066/satisfaction_details_silver_deltaload