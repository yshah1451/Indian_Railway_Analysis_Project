# Databricks notebook source
# MAGIC %md
# MAGIC ###Calculate satisfaction count on basis of satisfied and unsatisfied people.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Enable schema auto merge
# MAGIC SET spark.databricks.delta.schema.autoMerge.enabled = true;
# MAGIC
# MAGIC -- Create the table if it does not exist
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.Satisfaction_count_gold
# MAGIC USING DELTA 
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Output/Satisfaction_count_gold/';
# MAGIC
# MAGIC -- Insert data into the table
# MAGIC INSERT INTO ys255066.Satisfaction_count_gold
# MAGIC SELECT
# MAGIC     Satisfaction, 
# MAGIC     COUNT(*) AS Count,
# MAGIC     current_timestamp() AS Load_Time
# MAGIC FROM ys255066.satisfaction_details 
# MAGIC WHERE Is_Current = 1
# MAGIC GROUP BY Satisfaction;

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output:

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.Satisfaction_count_gold order by Load_Time desc

# COMMAND ----------

# MAGIC %md
# MAGIC ### Find top 5 destinations with maximum train arrivals
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table if it does not exist
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.Max_Train_Arrived_gold
# MAGIC USING DELTA 
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Output/Max_Train_Arrived_gold/';
# MAGIC
# MAGIC -- Insert data into the table
# MAGIC INSERT OVERWRITE ys255066.Max_Train_Arrived_gold
# MAGIC select Dest_station_name, count(*) AS Train_Count, current_timestamp() AS Load_Time from ys255066.railway_details
# MAGIC group by Dest_station_name
# MAGIC order by count(*) desc limit 5;

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output:

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.Max_Train_Arrived_gold order by Load_Time desc

# COMMAND ----------

# MAGIC %md
# MAGIC ### Analyze no. of trains delayed date wise
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table if it does not exist
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.Delay_Train_gold
# MAGIC USING DELTA 
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Output/Delay_Train_gold/';
# MAGIC
# MAGIC -- Insert data into the table
# MAGIC INSERT INTO ys255066.Delay_Train_gold
# MAGIC SELECT 
# MAGIC     COUNT(*) AS Total_Trains,
# MAGIC     SUM(CASE WHEN Delay > 0 THEN 1 ELSE 0 END) AS Delayed_Trains,
# MAGIC     SUM(CASE WHEN Delay = 0 THEN 1 ELSE 0 END) AS On_Time_Trains,
# MAGIC     DATE(Record_Load_Time) AS Delay_Date,
# MAGIC     current_timestamp() AS Load_Time
# MAGIC FROM ys255066.delay_details GROUP BY DATE(Record_Load_Time);

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output:

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.Delay_Train_gold order by load_time desc

# COMMAND ----------

# MAGIC %md
# MAGIC ### Find top 5 cities with Clean trains
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table if it does not exist
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.Clean_Train_gold
# MAGIC USING DELTA 
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Output/Clean_Train_gold/';
# MAGIC
# MAGIC -- Insert data into the table
# MAGIC INSERT OVERWRITE ys255066.Clean_Train_gold
# MAGIC select sd.Train_name,rd.Src_Station_name as City,count(*) as count,current_timestamp() AS Load_Time from ys255066.satisfaction_details sd inner join ys255066.railway_details rd on sd.Train_id = rd.Train_id and sd.Is_Current = 1 
# MAGIC where sd.cleanliness = 'yes' 
# MAGIC group by sd.Train_name,rd.Src_Station_name
# MAGIC order by count desc limit 5;

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.Clean_Train_gold

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Identify trains that arrived on time

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table if it does not exist
# MAGIC CREATE TABLE IF NOT EXISTS ys255066.Ontime_Train_gold
# MAGIC USING DELTA
# MAGIC LOCATION 'dbfs:/mnt/ys255066/Output/Ontime_Train_gold/';
# MAGIC
# MAGIC -- Insert data into the table
# MAGIC INSERT OVERWRITE ys255066.Ontime_Train_gold
# MAGIC select dd.Train_id,dd.Train_name,dd.Arrival_time,dd.Departure_time,dd.Delay,sd.Status,dd.Batch_Id,dd.Record_Load_Time,current_timestamp() AS Gold_Load_Time from ys255066.delay_details dd inner join ys255066.satisfaction_details sd on dd.Train_id = sd.Train_id 
# MAGIC where sd.Is_Current = 1 and dd.Delay = 0 and sd.Status = 'on time'

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output:

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ys255066.Ontime_Train_gold order by Gold_Load_Time desc