# Databricks notebook source
# MAGIC %run /Workspace/ys255066/mount_adls_container

# COMMAND ----------

from datetime import datetime

# Get current timestamp in YYYYMMDD_HHMMSS format
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

# Define source and destination paths
source_root = "dbfs:/mnt/ys255066/Inbound/"
destination_root = "dbfs:/mnt/ys255066/Archive/"

# Function to list all files recursively
def list_all_files(path):
    files = []
    items = dbutils.fs.ls(path)
    for item in items:
        if item.isFile():
            files.append(item.path)  # Add file path to list
        else:
            files.extend(list_all_files(item.path))  # Recurse into subdirectory
    return files

# Get all files inside Inbound recursively
all_files = list_all_files(source_root)

# Move and rename files
for file_path in all_files:
    relative_path = file_path.replace(source_root, "")  # Get relative path
    file_name = relative_path.split("/")[-1]  # Extract filename
    file_ext = file_name.split(".")[-1]  # Get file extension
    file_base_name = file_name[:-(len(file_ext) + 1)]  # Remove extension

    # New file name with timestamp suffix
    new_file_name = f"{file_base_name}_{timestamp}.{file_ext}"
    
    # Construct destination path (preserving hierarchy)
    new_file_path = destination_root + relative_path.replace(file_name, new_file_name)

    #  Move file
    dbutils.fs.mv(file_path, new_file_path)
    print(f"Moved {file_path} → {new_file_path}")  

print("✅ All files moved recursively while preserving hierarchy and adding full timestamp suffix.")
